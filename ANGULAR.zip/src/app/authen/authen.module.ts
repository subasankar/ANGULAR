import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AuthenRoutingModule } from './authen-routing.module';
import { LoginComponent } from './component/login/login.component';
import { RegisterComponent } from './component/register/register.component';
import { httpInterceptorProviders } from '../main/interceptors';
import { FormsModule } from '@angular/forms';
import { AuthenService } from './services/authen.service';

@NgModule({
  declarations: [LoginComponent, RegisterComponent],
  providers: [AuthenService, httpInterceptorProviders],
  imports: [CommonModule, FormsModule, AuthenRoutingModule, HttpClientModule],
})
export class AuthenModule {}
