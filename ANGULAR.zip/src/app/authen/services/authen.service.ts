import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AuthenService {
  constructor(private httpClient: HttpClient) {}

  registerUser(data: any): Observable<any> {
    return this.httpClient.post('/api/users', data);
  }
  loginUser(data: any): Observable<any> {
    return this.httpClient.post('/api/auth', data);
  }
  loadUser(): Observable<any> {
    return this.httpClient.get('/api/authen');
  }
}
