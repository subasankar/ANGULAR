import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Login } from '../../models/login';
import { AuthenService } from '../../services/authen.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  login: Login = new Login();

  constructor(private authService: AuthenService, private router: Router) {}

  loginSubmit() {
    console.log(JSON.stringify(this.login));

    const newUser: any = {
      email: this.login.email,
      password: this.login.password,
    };

    this.authService.loginUser(newUser).subscribe(
      (res) => {
        console.log('User Logged In successfully');
        this.router.navigate(['/dashboard']);
        console.log(JSON.stringify(res));
        localStorage.setItem('token', res.token);
      },
      (err) => {}
    );
  }

  ngOnInit(): void {}
}
