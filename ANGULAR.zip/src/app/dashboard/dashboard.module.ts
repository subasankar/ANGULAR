import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DashboardRoutingModule } from './dashboard-routing.module';
import { DashboardComponent } from './component/dashboard/dashboard.component';
import { httpInterceptorProviders } from '../main/interceptors';
import { AuthenService } from '../authen/services/authen.service';
import { CreateProfileService } from '../profile/services/create-profile.service';
import { HttpClientModule } from '@angular/common/http';
import { AuthenModule } from '../authen/authen.module';

@NgModule({
  declarations: [DashboardComponent],
  providers: [httpInterceptorProviders, AuthenService, CreateProfileService],
  imports: [
    CommonModule,
    DashboardRoutingModule,
    HttpClientModule,
    AuthenModule,
  ],
})
export class DashboardModule {}
