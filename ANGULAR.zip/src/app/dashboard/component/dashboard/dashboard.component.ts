import { Component, OnInit } from '@angular/core';
import { Register } from 'src/app/authen/models/register';
import { AuthenService } from 'src/app/authen/services/authen.service';
import { CreateProfile } from 'src/app/profile/models/create-profile';
import { CreateProfileService } from 'src/app/profile/services/create-profile.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
})
export class DashboardComponent implements OnInit {
  register: Register;
  profile: CreateProfile;
  constructor(
    private authenService: AuthenService,
    private profileService: CreateProfileService
  ) {}

  ngOnInit(): void {
    this.authenService.loadUser().subscribe((res) => {
      console.log(JSON.stringify(res));
      this.register = res;

      localStorage.setItem('users', JSON.stringify(res));
    });

    this.profileService.getProfile().subscribe((res) => {
      console.log(JSON.stringify(res));
      this.profile = res;

      localStorage.setItem('profile', JSON.stringify(res));
    });
    (err) => console.log(err);
  }
}
