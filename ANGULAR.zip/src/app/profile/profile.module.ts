import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProfileRoutingModule } from './profile-routing.module';
import { CreateProfileComponent } from './component/create-profile/create-profile.component';
import { httpInterceptorProviders } from '../main/interceptors';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { CreateProfileService } from './services/create-profile.service';

@NgModule({
  declarations: [CreateProfileComponent],
  imports: [CommonModule, FormsModule, HttpClientModule, ProfileRoutingModule],
  providers: [httpInterceptorProviders, CreateProfileService],
})
export class ProfileModule {}
