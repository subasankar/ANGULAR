import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MainRoutingModule } from './main-routing.module';
import { NavbarComponent } from './component/layout/navbar/navbar.component';
import { LandingComponent } from './component/layout/landing/landing.component';
import { FooterComponent } from './component/layout/footer/footer.component';
import { httpInterceptorProviders } from './interceptors';

@NgModule({
  declarations: [NavbarComponent, LandingComponent, FooterComponent],
  imports: [CommonModule, MainRoutingModule],
  providers: [httpInterceptorProviders],
  exports: [FooterComponent, LandingComponent, NavbarComponent],
})
export class MainModule {}
