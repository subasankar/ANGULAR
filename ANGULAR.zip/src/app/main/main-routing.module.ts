import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FooterComponent } from './component/layout/footer/footer.component';
import { LandingComponent } from './component/layout/landing/landing.component';
import { NavbarComponent } from './component/layout/navbar/navbar.component';

const routes: Routes = [];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MainRoutingModule {}
